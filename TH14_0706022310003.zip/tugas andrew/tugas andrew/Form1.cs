﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas_andrew
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;
        MySqlDataAdapter sqldataadapter;

        DataTable dgv = new DataTable();
        DataTable dtmtch = new DataTable();
        DataTable datatimhome = new DataTable();
        DataTable datatimaway = new DataTable();
        DataTable datatipe = new DataTable();
        DataTable datapemain = new DataTable();
        DataTable tanggalterakhir = new DataTable();
        DataTable data = new DataTable();
        DataTable dataidpertandingan = new DataTable();
        string querry = "";
        string tahun = "";
        string bulan = "";
        string tanggal = "";
        int totaltanding = 0;
        int akhir = 0;
        int pilih = 0;
        int totalhome = 0;
        int totalaway = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                sqlconnect = new MySqlConnection("server = localhost; uid = root; pwd = MySQLISBUC2024Sean; database = premier_league");
                sqlconnect.Open();
                querry = "SELECT * From Team";
                sqlcommand = new MySqlCommand(querry, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(datatimhome);
                sqldataadapter.Fill(datatimaway); querry = "select * from `dmatch`";
                sqlcommand = new MySqlCommand(querry, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(datatipe);
                sqlconnect.Close();
                comboBox_TimHome.DataSource = datatimhome;
                comboBox_TimHome.DisplayMember = "team_name";
                comboBox_TimHome.ValueMember = "team_id";
                comboBox_TimHome.Text = "";
                comboBox_TimAway.DataSource = datatimaway;
                comboBox_TimAway.DisplayMember = "team_name";
                comboBox_TimAway.ValueMember = "team_id";
                comboBox_TimAway.Text = "";
                comboBox_Tim.DataSource = datatimhome;
                comboBox_Tim.DisplayMember = "team_name";
                comboBox_Tim.ValueMember = "team_id";
                dgv.Columns.Add("Team");
                dgv.Columns.Add("Player");
                dgv.Columns.Add("Type");
                dgv_1.DataSource = dgv;
                dtmtch.Columns.Add("Minute");
                dtmtch.Columns.Add("team_id");
                dtmtch.Columns.Add("player_id");
                dtmtch.Columns.Add("Type");
                comboBox_Tim.Text = "";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox_dataidpertandingan.Text != "")
                {
                    for (int i = 0; i < dgv.Rows.Count; i++)
                    {
                        querry = $"INSERT INTO DMatch VALUES ('{textBox_dataidpertandingan.Text}', '{dtmtch.Rows[i][0]}', '{dtmtch.Rows[i][1]}', '{dtmtch.Rows[i][2]}', '{dtmtch.Rows[i][3]}', '0');";
                        sqlconnect.Open();
                        sqlcommand = new MySqlCommand(querry, sqlconnect);
                        sqlcommand.ExecuteNonQuery();
                        sqlconnect.Close();
                    }
                    querry = $"INSERT INTO `match` VALUES ('{textBox_dataidpertandingan.Text}', '{tahun}-{bulan}-{tanggal}', '{comboBox_TimHome.SelectedValue}', '{comboBox_TimAway.SelectedValue}', '{totalhome}', '{totalaway}', 'M002', '0');";
                    sqlconnect.Open();
                    sqlcommand = new MySqlCommand(querry, sqlconnect);
                    sqlcommand.ExecuteNonQuery();
                    sqlconnect.Close();
                    comboBox_TimAway.Text = "";
                    comboBox_TimHome.Text = "";
                    textBox_Menit.Text = "";
                    comboBox_Tipe.Text = "";
                    comboBox_Tim.Text = "";
                    comboBox_Pemain.Text = "";
                    textBox_dataidpertandingan.Text = "";
                    dgv.Rows.Clear();
                    dtmtch.Rows.Clear();
                    totalaway = 0;
                    totalhome = 0;
                }
                else
                {
                    MessageBox.Show("Fill all the fields!", "ERROR");
                }
            }

            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void button_Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox_Menit.Text == "" || comboBox_Tim.Text == "" || comboBox_Pemain.Text == "" || comboBox_Tipe.Text == "" || textBox_dataidpertandingan.Text == "")
                {
                    MessageBox.Show("Bang, Masi Kosong bang");
                }
                else
                {
                    dgv.Rows.Add(comboBox_Tim.Text, comboBox_Pemain.Text, comboBox_Tipe.Text);
                    if (comboBox_Tipe.Text == "GO" || comboBox_Tipe.Text == "GP")
                    {
                        if (comboBox_TimAway.Text == comboBox_Tim.Text)
                        {
                            totalaway++;
                        }
                        else
                        {
                            totalhome++;
                        }
                    }
                    if (comboBox_Tipe.Text == "GW")
                    {
                        if (comboBox_TimAway.Text == comboBox_Tim.Text)
                        {
                            totalhome++;
                        }
                        else
                        {
                            totalaway++;
                        }
                    }
                    dtmtch.Rows.Add(textBox_Menit.Text, comboBox_Tim.SelectedValue, comboBox_Pemain.SelectedValue, comboBox_Tipe.Text);
                    textBox_dataidpertandingan.Clear();
                    textBox_Menit.Clear();
                    comboBox_Tipe.SelectedIndex = 0;
                    comboBox_Tim.SelectedIndex = 0;
                    comboBox_Pemain.SelectedIndex = 0;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_1.Rows.Count > 0)
                {
                    dgv_1.Rows.RemoveAt(dgv_1.SelectedRows[0].Index);
                    if (comboBox_Tipe.Text == "GO" || comboBox_Tipe.Text == "GP")
                    {
                        if (comboBox_TimAway.Text == comboBox_Tim.Text)
                        {
                            totalaway--;
                        }
                        else
                        {
                            totalhome--;
                        }
                    }
                    if (comboBox_Tipe.Text == "GW")
                    {
                        if (comboBox_TimAway.Text == comboBox_Tim.Text)
                        {
                            totalhome--;
                        }
                        else
                        {
                            totalaway--;
                        }
                    }
                }

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox_TimHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox_TimHome.Text == comboBox_TimAway.Text)
                {
                    MessageBox.Show("Cannot Pick The same team");
                }
                else
                {
                    data = new DataTable();
                    querry = $"SELECT team_name, team_id FROM team WHERE team_id = '{comboBox_TimHome.SelectedValue}' or team_id = '{comboBox_TimAway.SelectedValue}'";
                    sqlcommand = new MySqlCommand(querry, sqlconnect);
                    sqldataadapter = new MySqlDataAdapter(sqlcommand);
                    sqldataadapter.Fill(data);

                    comboBox_Tim.ValueMember = "team_id";
                    comboBox_Tim.DisplayMember = "team_name";
                    comboBox_Tim.DataSource = data;
                    comboBox_Tim.Text = "";
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox_TimAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox_TimAway.Text == comboBox_TimHome.Text)
                {
                    MessageBox.Show("Cannot Pick the Same team");
                }
                else
                {
                    data = new DataTable();
                    querry = $"SELECT team_name, team_id FROM team WHERE team_id = '{comboBox_TimHome.SelectedValue}' or team_id = '{comboBox_TimAway.SelectedValue}'";
                    sqlcommand = new MySqlCommand(querry, sqlconnect);
                    sqldataadapter = new MySqlDataAdapter(sqlcommand);
                    sqldataadapter.Fill(data);

                    comboBox_Tim.ValueMember = "team_id";
                    comboBox_Tim.DisplayMember = "team_name";
                    comboBox_Tim.DataSource = data;
                    comboBox_Tim.Text = "";
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void DateTime_waktupertandingan_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                querry = $"SELECT concat(date_format(match_date, '%Y'), date_format(match_date, '%m'), date_format(match_Date, '%d')) FROM `match` ORDER BY 1 desc LIMIT 1";
                sqlcommand = new MySqlCommand(querry, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(tanggalterakhir);
                tahun = DateTime_waktupertandingan.Value.Year.ToString();
                bulan = DateTime_waktupertandingan.Value.Month.ToString();
                tanggal = DateTime_waktupertandingan.Value.Day.ToString();
                if (Convert.ToInt32(bulan) < 10)
                {
                    bulan = "0" + bulan;
                }
                if (Convert.ToInt32(tanggal) < 10)
                {
                    bulan = "0" + tanggal;
                }
                pilih = Convert.ToInt32(tahun + bulan + tanggal);
                akhir = Convert.ToInt32(tanggalterakhir.Rows[0][0]);
                if (pilih < akhir)
                {
                    MessageBox.Show("Date Picked Cannot be earlier than the last match");
                }
                else
                {
                    querry = $"SELECT match_id FROM `match` WHERE match_id like '{tahun}%' ORDER BY 1 desc LIMIT 1 ";
                    sqlcommand = new MySqlCommand(querry, sqlconnect);
                    sqldataadapter = new MySqlDataAdapter(sqlcommand);
                    sqldataadapter.Fill(dataidpertandingan);

                    if (dataidpertandingan.Rows.Count == 0)
                    {
                        textBox_dataidpertandingan.Text = tahun + "001";
                    }
                    else if (dataidpertandingan.Rows.Count == 1)
                    {
                        totaltanding = Convert.ToInt32(dataidpertandingan.Rows[0][0]) + 1;
                        textBox_dataidpertandingan.Text = totaltanding.ToString();
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void textBox_Menit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox_Tim_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_Tim.Text != "")
            {
                datapemain = new DataTable();
                querry = $"SELECT p.player_name, p.player_id from player p, team t where t.team_id = '{comboBox_Tim.SelectedValue}'";
                sqlcommand = new MySqlCommand(querry, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(datapemain);
                comboBox_Pemain.ValueMember = "player_id";
                comboBox_Pemain.DisplayMember = "player_name";
                comboBox_Pemain.DataSource = datapemain;
                comboBox_Pemain.Text = "";
            }
        }
    }
}
